// script.js

document.querySelector('.cta button').addEventListener('click', function() {
    alert('Redirecting to signup page...');
    // Here you can redirect to the signup page
    window.location.href = 'signup.html';
  });